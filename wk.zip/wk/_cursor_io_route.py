import os
import sys
import datetime

import arcpy

arcpy.CheckOutExtension("network")

# data locations

cwd = os.path.dirname(os.path.abspath(__file__))
nd_path = os.path.join(cwd, r'SanFrancisco.gdb\Transportation\Streets_ND')
nd_layer_name = "SanFrancisco"

arcpy.nax.MakeNetworkDatasetLayer(nd_path, nd_layer_name)

# create new route solver

route = arcpy.nax.Route(nd_layer_name)

# analysis settings

route.timeOfDay = datetime.datetime.now()
route.returnDirections = True

# load data using an insert cursor

with route.insertCursor(arcpy.nax.RouteInputDataType.Stops, ["Name", "SHAPE@XY",]) as stops_insert_cursor:
    stops_insert_cursor.insertRow(["Home", (-122.4378792, 37.7955582)])
    stops_insert_cursor.insertRow(["Work", (-122.3979990, 37.7936440)])

# solve route

result = route.solve()

if not result.solveSucceeded:
    print("Solved failed")
    print(result.solverMessages(arcpy.nax.MessageSeverity.All))
    sys.exit(0)

# examine result with a search cursor

for row in result.searchCursor(arcpy.nax.RouteOutputDataType.Directions, ["ArriveTime", "Text"]):
    print(f'{row[0]:%H:%M:%S} {row[1]}')