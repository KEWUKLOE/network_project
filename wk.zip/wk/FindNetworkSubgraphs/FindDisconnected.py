############################################################################
## Tool name: Find Network Subgraphs
## Created by: kewu
## Last updated: 21 May 2024
############################################################################
''' The Find Network Subgraphs tool helps you identify topologically
disconnected areas of your network dataset.  It is meant for identifying
potential problems with your network dataset.

When you run this tool on a network dataset, it will identify the "subgraphs",
meaning sets of mutually connected network edges that are disconnected from
other sets within the network.  These subgraphs could indicate areas that are
disconnected by accident because of errors in geometry or with the network's
connectivity policy.  Or, they could be disconnected on purpose (an island
with no roads connecting to the mainland, for example).

The tool will add a field, "subgraph", to each edge source feature class of
the network dataset.  The subgraph of a feature represents the group of
mutually-connected edges the feature belongs to. Features with the same
subgraph value are connected to each other but are disconnected from features
with other “subgraph values. Subgraph 0 represents the main part of the
network dataset, the subgraph with the largest number of edges.  A fully
connected network dataset has only one subgraph.

The tool will add the network source feature classes to the map and symbolize
them to emphasize features that are not in the main subgraph (those with non-0
subgraph values).  The tool messages will report the total number of subgraphs
in the network.
'''
################################################################################
'''Copyright 2024 ke wu for educational usage
   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at
       http://www.apache.org/licenses/LICENSE-2.0
   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.'''
################################################################################

import os
import sys
import arcpy

try:
    import networkx
except ImportError:
    arcpy.AddError("You must install the networkx python package before running this tool.")
    sys.exit()

arcpy.env.overwriteOutput = True
arcpy.CheckOutExtension("network")

NDpath = arcpy.GetParameter(0)

# Create network dataset object
ND = arcpy.nax.NetworkDataset(NDpath)
if not ND.isBuilt:
    arcpy.AddError("The network dataset is not built.")
    sys.exit()

fld_sourceid = "SOURCEID"
fld_sourceoid = "SOURCEOID"
fld_subgraph = "subgraph"
source_ids = []
out_fcs = []

# Create a temporary table for storing subgraphs
out_subgraph_table = os.path.join(arcpy.env.scratchGDB, "Subgraphs")
arcpy.management.CreateTable(os.path.dirname(out_subgraph_table), os.path.basename(out_subgraph_table))
arcpy.management.AddFields(out_subgraph_table,
                           [[fld_sourceid, "SHORT"], [fld_sourceoid, "LONG"], [fld_subgraph, "SHORT"]])

# Initialize networkx graph
# Use a non-directed multigraph so we can have parallel edges and self-loops, but direction of travel doesn't matter.
graph = networkx.MultiGraph()

# Add all network edges to networkx graph
arcpy.AddMessage("Creating graph from network edges...")
props = [fld_sourceid, fld_sourceoid, "DIRECTION", "FROMJUNCTION", "TOJUNCTION"]
for edge in ND.edges(props):
    if not edge[2]:
        # This is a non-directed graph, so skip all the edges in the backwards direction.
        continue
    from_junc = edge[3]
    to_junc = edge[4]
    source_id = edge[0]
    source_oid = edge[1]
    # Create list of all source ids for later use
    if source_id not in source_ids:
        source_ids.append(source_id)
    # Store sourceid and sourceoid for each edge
    edge_attrs = {fld_sourceid: source_id, fld_sourceoid: source_oid}
    # Add the edge to the graph
    graph.add_edge(from_junc, to_junc, attr_dict=edge_attrs)

# Calculate the connected components of the graph and sort them by size (largest first)
arcpy.AddMessage("Calculating subgraphs...")
components = sorted(networkx.connected_components(graph), key=len, reverse=True)
num_components = len(components)
arcpy.AddMessage(f"Number subgraphs in network: {num_components}")
if num_components == 1:
    arcpy.AddMessage("The network dataset does not have any disconnected parts.")
    arcpy.SetParameter(1, num_components)
    arcpy.SetParameter(2, out_fcs)
    sys.exit()

# Iterate over the graph components and write the sourceid, sourceoids to a table together with the subgraph
# number they belong to
arcpy.AddMessage("Writing results...")
with arcpy.da.InsertCursor(out_subgraph_table, [fld_sourceid, fld_sourceoid, fld_subgraph]) as cur:
    for idx, comp in enumerate(components):
        for (u, v, attrs) in graph.edges(comp, data=True):
            cur.insertRow((attrs["attr_dict"][fld_sourceid], attrs["attr_dict"][fld_sourceoid], idx))

# For each edge source, populate a subgraph field indicating which subgraph the feature belongs to
for source in source_ids:
    fc = ND.getDataSourceFromSourceID(source)
    out_fcs.append(fc)
    desc = arcpy.Describe(fc)
    if fld_subgraph in [f.name for f in desc.fields]:
        # Delete the subgraph field if it's already there
        arcpy.management.DeleteField(fc, fld_subgraph)
    # Create a table view to select only rows with this sourceid
    tv = arcpy.management.MakeTableView(out_subgraph_table, "Source table view", f"{fld_sourceid} = {source}")
    # Use JoinField to join transfer the subgraph field from the temporary table into the output
    arcpy.management.JoinField(fc, arcpy.Describe(fc).OIDFieldName, tv, fld_sourceoid, fld_subgraph)

# Set tool outputs
arcpy.SetParameter(1, num_components)
arcpy.SetParameter(2, out_fcs)

# Clean up
arcpy.management.Delete(out_subgraph_table)