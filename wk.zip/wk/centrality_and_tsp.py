#!/usr/bin/env python
# coding: utf-8

# In[13]:


import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt


data = pd.read_csv('desktop/lines.csv')


G = nx.DiGraph()


for index, row in data.iterrows():
    G.add_edge(row['OriginOID'], row['DestinationOID'], weight=row['Total_Distance'])


closeness = nx.closeness_centrality(G, distance='weight')


max_closeness_node = max(closeness, key=closeness.get)
print(f"Node with highest closeness centrality: {max_closeness_node} (Closeness: {closeness[max_closeness_node]:.2f})")


pos = nx.spring_layout(G) 
options = {
    "node_color": "blue",
    "edge_color": "gray",
    "node_size": 50,
    "linewidths": 0.5,
    "font_size": 8,
    "width": 0.5,
}
nx.draw(G, pos, **options)


nx.draw_networkx_nodes(G, pos, nodelist=[max_closeness_node], node_size=100, node_color="red")
nx.draw_networkx_edges(G, pos, edgelist=G.edges(max_closeness_node), edge_color="red", width=1.5)

plt.title("Network Visualization with Center Node Highlighted")
plt.show()


# In[15]:


import pandas as pd
import networkx as nx
from networkx.algorithms.approximation import traveling_salesman


data = pd.read_csv('desktop/lines.csv') 


G = nx.DiGraph()
for idx, row in data.iterrows():
    G.add_edge(row['OriginOID'], row['DestinationOID'], weight=row['Total_Time']) 


nodes_to_visit = [1, 2, 3, 4, 5] 


H = G.subgraph(nodes_to_visit)


cycle = traveling_salesman.greedy_tsp(H, weight='weight')


print("Approximate shortest cycle through specified nodes:", cycle)


# In[ ]:





# In[ ]:




